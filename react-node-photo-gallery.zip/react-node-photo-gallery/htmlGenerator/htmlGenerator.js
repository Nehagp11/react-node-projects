var contentDiv = $('.content-div');
var generatedHtml = $('#generatedHtml');

var content = generatedHtml.val();

function updateViewPart () {
    content = generatedHtml.val().replace(/\s\s+/g, ' ').replace(/(\r\n|\n|\r)/gm," ");
    generatedHtml.val(content);
    contentDiv.html(content);
}

function myFunction(ele) {
    document.getElementById(ele).classList.toggle("show");
}

window.onclick = function(e) {
    if (!e.target.matches('.dropbtn')) {
        var myDropdown = document.getElementById("myDropdown");
        if (myDropdown.classList.contains('show')) {
            myDropdown.classList.remove('show');
        }
        var myDropdown = document.getElementById("innerDropDown");
        if (myDropdown.classList.contains('show')) {
            myDropdown.classList.remove('show');
        }
    }
}

var prevForm;

function reset() {
    $('.error').hide();
    $('.selectError').hide();
    $('.form-horizontal').each(function () {
        if(!($(this).hasClass('hidden'))){
            $(this).addClass('hidden');
        }
    });
    $('.checkBoxBtn').prop('checked', false);
}

var currentItem, currentInnerItem;

$("#myDropdown li").click(function () {
    reset();
    prevForm = prevParent = prevActive = null;
    if($(this).attr('id') == 'lineBreak'){
        addLineBreak();
    }
    else {
        currentItem = $(this).attr('id') + "Form";
        $("#" + currentItem).removeClass('hidden');
        $('.modal-title').text('Insert '+ $(this).text());
        $("#htmlInputModal").modal('show');
    }
});

var currentListType, currentList, count, prevActive, prevParent;

$('body').on('blur', '.form-control, li input', function () {
    prevActive = $(this);
});

$('#innerDropDown li').click(function () {
    prevForm = currentItem;
    if($("#" + prevForm).has(prevActive).length){
        prevParent = prevActive;
    }
    if($(this).attr('id') == 'lineBreak'){
        addLineBreak();
    }
    else {
        reset();
        currentInnerItem = $(this).attr('id') + "Form";
        $("#" + currentInnerItem).removeClass('hidden');
        $('.modal-title').text('Insert '+ $(this).text());
    }
});

var addedLink;
function addHyperLink() {
    if(selectedText){
        startIndex = selectedItem.selectionStart;
        endIndex = selectedItem.selectionEnd;
        selectedParent = selectedItem;
        $("#innerDropDown #link").trigger('click');
        $('#linkText').val(selectedText);
        addedLink = true;
    }
    else selectText();
}

function selectText() {
    $('.selectError').show();
}

function switChFunc(currentItem) {
    var text, fontsize = '',paraFontSize = '';
    if($('#fontSize').val() != 'default'){
        fontsize = 'style="font-size:'+ $('#fontSize').val() + '"';
    }
    switch(currentItem){
        case 'headingForm':
            text = '<h3'+ ' class="'+ $("#headingClass").val() +'" '+fontsize+ '>' + $("#headingText").val() + '</h3>';
            $("#headingText").val('');
            break;
        case 'paragraphForm':
            if($('#paraFontSize').val() != 'default'){
                paraFontSize = 'style="font-size:'+ $('#paraFontSize').val() + '"';
            }
            if($("#subHeadingText").val())
                text = '<h4 class=\"'+ $("#subheadingClass").val() +'\" '+fontsize+'>' + $("#subHeadingText").val() + '</h4><p class="'+ $("#paraClass").val()+ '" '+paraFontSize+'>' + $("#paraContent").val() + "</p>";
            else
                text = '<p class="'+ $("#paraClass").val()+ '" '+paraFontSize+'>' + $("#paraContent").val() + "</p>";
            $("#subHeadingText").val('');
            $('#paraContent').val('');
            $('#paraFontSize').val('default');
            break;
        case 'imageForm':
            text = '<img src="'+ $("#imageSrc").val() + '" class = "'+ $("#imageClass").val() + '" alt="'+ $("#imageAlt").val() +'" '+fontsize+' width="'+ ($("#imageWidth").val() || "auto") + '" height= "'+ ($("#imageWidth").val() || "auto") + '">';
            $("#imageSrc").val('');
            $("#imageWidth").val('');
            $("#imageHeight").val('');
            $('#imageAlt').val('');
            break;
        case 'linkForm':
            text = '<a href="'+ $("#urlText").val() + '" class="'+ $("#linkClass").val() + '" target="' + $("#targetVal").val() + '" title="' + $("#linkTitle").val() + '" '+fontsize+'>' + $("#linkText").val() + '</a>';
            $("#urlText").val('');
            $("#linkTitle").val('');
            $("#targetVal").val('');
            $("#linkText").val('');
            break;
        case 'orderedListForm':
            currentListType = $("#olListType").val();
            count = parseInt($("#itemCount").val());
            var container = $('<ol type="' + currentListType+ '"></ol>');
            for(var i = 1; i <= count; i++) {
                container.append('<li><input id="Itemid'+i+'" required/></li>');
            }
            currentList = 'ol';
            $('#itemsForm').html(container);
            if(currentItem == currentInnerItem){
                setTimeout(function () {
                    $("#innerDropDown #items").trigger('click');
                }, 400);
            }
            else {
                setTimeout(function () {
                    $("#items").trigger('click');
                }, 400);
            }
            $("#itemCount").val('');
            return;
            break;
        case 'unorderedListForm':
            currentListType = $("#ulListType").val();
            count = parseInt($("#ulitemCount").val());
            var container = $('<ul type="' + currentListType+ '"></ul>');
            for(var i = 1; i <= count; i++) {
                container.append('<li><input id="Itemid'+i+'" required/></li>');
            }
            currentList = 'ul';
            $('#itemsForm').html(container);
            if(currentItem == currentInnerItem){
                setTimeout(function () {
                    $("#innerDropDown #items").trigger('click');
                }, 400);
            }
            else {
                setTimeout(function () {
                    $("#items").trigger('click');
                }, 400);
            }
            $("#ulitemCount").val('');
            return;
            break;
        case 'itemsForm':
            text = '';
            for(var i=1; i<=count; i++){
                text += '<li ' +fontsize + '>' + $("#Itemid" + i).val() + '</li>';
            }
            if(currentList == 'ol'){
                text = '<ol type="' + currentListType+ '" class="'+ $('#olClass').val() + '">'+ text +'</ol>';
            }
            else {
                text = '<ul type="' + currentListType+ '" class="'+ $('#olClass').val() + '">'+ text +'</ul>';
            }
            break;
        /* case 'metaTagForm':
            text = '<meta name="'+ $('#metaTagName').val()+'" content="'+ $('#metaContent').val() +'">';
            $('#metaContent').val('');
            break; */
    }
    if($('#fontSize').val() != 'default'){
        $('#fontSize').val('default');
    }
    return text;
}

function checkStatus(currentItem) {
    var proceed = true;
    $("#"+currentItem + " input[required]").each(function () {
        if(!($(this).val())) {
            proceed = false;
            return;
        }
    });
    $("#"+currentItem + " textarea[required]").each(function () {
        if(!($(this).val())) {
            proceed = false;
            return;
        }
    });
    if(proceed == false) {
        $('.error').show();
        return false;
    }
    else
        return true;
}

$("#submitForm").click(function(e){
    var proceed = true, entireContent;
    var text = '', html = '';
    var headText, generatedHtmlContent;

    if(currentInnerItem){
        proceed = checkStatus(currentInnerItem);
        if(proceed){
            text = switChFunc(currentInnerItem);
        }
    }
    else{
        proceed = checkStatus(currentItem);
        if(proceed){
            $("#htmlInputModal").modal('hide');
            text = switChFunc(currentItem);
        }
    }

    if(!proceed)
        return false;

    /*if(currentItem == 'metaTagForm' && text){
        generatedHtmlContent = $('#generatedHtml').val();
        if(generatedHtmlContent.indexOf('<head>') == -1 || generatedHtmlContent.indexOf('</head>') == -1){
            headText = '<head>' + text + '</head>';
            $('#generatedHtml').val(headText + generatedHtmlContent);
        }
        else {
            headText = generatedHtmlContent.indexOf('</head>');
            $('#generatedHtml').val(generatedHtmlContent.substring(0, headText) + text + generatedHtmlContent.substring(headText));
        }
    } */

    else if(addedLink){
        selectedParent.value = selectedParent.value.substring(0, startIndex) + text + selectedParent.value.substring(endIndex);
        $("#" + currentInnerItem).addClass('hidden');
        $("#" + prevForm).removeClass('hidden');
        currentInnerItem = null;
        addedLink = null;
    }

    else if(text && prevForm && prevParent && currentInnerItem){
        entireContent = prevParent.val() + text;
        prevParent.val(entireContent);
        $("#" + currentInnerItem).addClass('hidden');
        $("#" + prevForm).removeClass('hidden');
        currentInnerItem = null;
    }
    else if(text){
        contentDiv.append(text);
        html = generatedHtml.val() + text;
        html = html.replace(/\s\s+/g, ' ');
        generatedHtml.val(html);
    }
    e.preventDefault();
});

/*function updateViewPart () {
    var text = generatedHtml.val();
    contentDiv.html(text);
}*/

function addLineBreak() {
    var text = '<br>';
    if(text && prevForm && prevParent){
        entireContent = prevParent.val() + text;
        prevParent.val(entireContent);
    }
    else{
        contentDiv.append(text);
        var html = generatedHtml.val() + text;
        generatedHtml.val(html);
    }
}

var selectedText, selectedItem, selectedItemId, startIndex, endIndex;

$('body').on('select', '.form-control, li input', function () {
    selectedItemId = $(this).attr('id');
    selectedItem = document.getElementById(selectedItemId);
    selectedText = selectedItem.value.substring(selectedItem.selectionStart, selectedItem.selectionEnd);
});

$('.checkBoxBtn').change(function () {
    var selectedCheckBox = $(this).attr('id');
    if(selectedText){
        switch (selectedCheckBox) {
            case 'boldText' :
                if ($("#" + selectedCheckBox).prop('checked')) {
                    selectedText = "<b>" + selectedText + "</b>";
                    selectedItem.value = selectedItem.value.substring(0, selectedItem.selectionStart) + selectedText + selectedItem.value.substring(selectedItem.selectionEnd);
                }
                break;
            case 'italicText' :
                if ($("#" + selectedCheckBox).prop('checked')) {
                    selectedText = "<i>" + selectedText + "</i>";
                    selectedItem.value = selectedItem.value.substring(0, selectedItem.selectionStart) + selectedText + selectedItem.value.substring(selectedItem.selectionEnd);
                }
                break;
            case 'underlinedText' :
                if ($("#" + selectedCheckBox).prop('checked')) {
                    selectedText = "<u>" + selectedText + "</u>";
                    selectedItem.value = selectedItem.value.substring(0, selectedItem.selectionStart) + selectedText + selectedItem.value.substring(selectedItem.selectionEnd);
                }
                break;
            case 'strikeThrough' :
                if ($("#" + selectedCheckBox).prop('checked')) {
                    selectedText = "<s>" + selectedText + "</s>";
                    selectedItem.value = selectedItem.value.substring(0, selectedItem.selectionStart) + selectedText + selectedItem.value.substring(selectedItem.selectionEnd);
                }
                break;
        }

    }
    else{
        selectText();
    }

});

function addEscapeChar() {
    var content = generatedHtml.val().replace(/"/g, '\\"');
    generatedHtml.val(content);
}