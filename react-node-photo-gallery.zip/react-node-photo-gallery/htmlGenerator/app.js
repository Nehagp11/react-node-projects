// Create a vanilla JS application that consumes the https://pokeapi.co/api/v2/pokemon/ API and 
// displays a dropdown list of pokemons. When the user selects a pokemon from the dropdown, 
// the application should make a second API call using the "url" returned in the first API call
// to fetch the pokemon's details, including its abilities, and display them on the page. 
// Once the details are fetched, they should be cached and the application should not make another API call for that pokemon again.		

const url = "https://pokeapi.co/api/v2/pokemon/";
const selectBtn = document.getElementById('pokemon-list');

async function getPokemonData(url){
    let data = await fetch(url, {method : "GET"}).then((res) => res.json());
    let options = "";
    if(data.results && data.results.length){
        for(let i = 0; i < data.results.length; i++){
            let currentElem = data.results[i];
            options += `<option data-url="${currentElem.url}">${currentElem.name}</option> `
        }
        selectBtn.innerHTML = options;
    }
}

async function getPokemonDetailData(url, name){
    let res = await fetch(url, {method : "GET"});
    let data = await res.json();
    let details = `Name : ${name}, Abilities : `
    if(data.abilities && data.abilities.length){
        let currentData = data.abilities;
        for(let i = 0; i < currentData.length; i++){
            let currentElem = currentData[i].ability && currentData[i].ability.name;
            details += currentElem;
            details += ' ';
        }
        selectBtn.innerHTML = options;
    }
}

getPokemonData(url);

document.body.addEventListener('click', '#pokemon-list option', function(e){
    var ele = e.target;
    var currentUrl = ele.dataset.url;
    getPokemonDetailData(currentUrl);
});



