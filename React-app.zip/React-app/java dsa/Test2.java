import java.util.ArrayList;
import java.util.List;

public class Test2 {
    public static List<Integer> getSubArray(int[] arr, int k){
        int size = arr.length;
        List<Integer> output = new ArrayList<Integer>();

        int sum = 0, maxlength = 0, startIndex = 0;
        int i = 0, j = i;
        sum += arr[i];

        while(i <= j && j < size - 1){
            if(sum == k && maxlength < j - i + 1){
                maxlength = j - i + 1;
                startIndex = i;
            } else if(sum > k){
                sum -= arr[i];
                i++;
            }
            j++;
            sum += arr[j]; 
        }


        for(i = startIndex; i < maxlength + startIndex && i < size; i++){
            output.add(arr[i]);
            // System.out.println(arr[i]);
            // System.out.println(i);
        }
        System.out.println(output);
        return output;
    }

    public static void main(String[] args) {
        int [] arr = {10, 5, 9, 5, 1, 8, 5};
        getSubArray(arr, 15);
    }
}


// 