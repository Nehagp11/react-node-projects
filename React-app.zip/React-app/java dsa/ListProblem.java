import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ListProblem {
    static boolean allPairExist(ArrayList<int[]> shoes){
        int size = shoes.size();
        for(int i = 0; i < size; i++){
            int[] currentShoe = shoes.get(i);
            int [] otherpair = new int[2];
            otherpair[0] = 1- currentShoe[0];
            otherpair[1] = currentShoe[1];
            if(!shoes.contains(otherpair)){
                return false;
            }
        }
        return true;
    }

    static void divideArrayintoList(int[] arr){
        int n = arr.length;
        ArrayList<Integer> list1 = new ArrayList<Integer>();
        ArrayList<Integer> list2 = new ArrayList<Integer>();
        if(n%2 != 0 || n < 2){
            System.out.println("Array division is not possible");
            return;
        }
        Arrays.sort(arr);
        int i = 0, j = n - 3;
        int list1Sum = arr[n-1], list2Sum = arr[n-2];
        list1.add(arr[n-1]);
        list2.add(arr[n-2]);
        while(i < j){
            if(list1Sum > list2Sum){
                list1.add(arr[i]);
                list2.add(arr[j]);
                list1Sum += arr[i];
                list2Sum += arr[j];
            } else {
                list1.add(arr[j]);
                list2.add(arr[i]);
                list1Sum += arr[j];
                list2Sum += arr[i];
            }
            i++;
            j--;
        }

        System.out.println(list1);
        System.out.println(list1Sum);
        System.out.println(list2);
        System.out.println(list2Sum);
    }

    public static void main(String[] args){
        ArrayList<int[]> shoes = new ArrayList<int[]>();
        int [] shoe1 = {1, 21};
        int [] shoe2 = {1, 23};
        int [] shoe3 = {0, 23};
        int [] shoe4 = {0, 21};

        shoes.add(shoe1);
        shoes.add(shoe2);
        shoes.add(shoe3);
        shoes.add(shoe4);

        System.out.println("pair exists : "+ allPairExist(shoes));

        int arr [] =  {1000,500,200,1,5,10,50,70,70,100};

        divideArrayintoList(arr);

        List <String> list2 = new CopyOnWriteArrayList<>();

        list2.add("a");
        list2.add("b");
        
        Iterator<String> itr = list2.iterator();

        while(itr.hasNext()){
            System.out.println(itr.next());
            list2.add("c");
        }

        System.out.println(list2);

    }
}