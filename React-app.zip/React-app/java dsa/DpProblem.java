import java.util.Arrays;
import java.util.Stack;

class DpProblem {
    
    static String longestValidParenthesisSubstString(String str){
        String output = "";
        int endIndex = 0;
        int n = str.length();
        int maxlength = 0;

        int[] longest = new int[n];
        Arrays.fill(longest, 0);

        // starts from second character 
        for(int i = 1; i < n; i++){
            // check if current character is closing bracket 
            if(str.charAt(i) == ')' && i - longest[i - 1] - 1 >= 0 && str.charAt(i - longest[i - 1] - 1) == '('){
                longest[i] = longest[i - 1] + 2;
                if(i - longest[i - 1] - 2 >= 0){
                    longest[i] = longest[i] + longest[i - longest[i-1] - 2];
                }
                if(longest[i] > maxlength){
                    maxlength = longest[i];
                    endIndex = i;
                }
            }
        }
        output = str.substring(endIndex - maxlength + 1, endIndex + 1);
        return output;
    }

       // Driver code
    public static void main(String[] args) {
        String str = "((()()";
        // Function call
        System.out.print(longestValidParenthesisSubstString(str) + "\n");
 
        str = "()(()))))";
 
        // Function call
        System.out.print(longestValidParenthesisSubstString(str) + "\n");
    }
}