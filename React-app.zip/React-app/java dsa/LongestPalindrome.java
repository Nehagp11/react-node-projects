import java.util.Arrays;

class LongestPalindrome {
    
    static String findLongstPalindromSubString(String str){
        String reString = "";
        int size = str.length();
        int maxlength = size > 1 ? 1 : size;
        int startIndex = 0;
        
        int [][] dp = new int[size][size];
        for(int [] row : dp){
            Arrays.fill(row, 0);
        }
        // Arrays.fill(dp, 0);
        int i = 0, j = 0;
        for(i = 0; i < size - 1; i++){
            if(str.charAt(i) == str.charAt(i + 1)){
                dp[i][i+1] = 2;
                if(maxlength < 2){
                    maxlength = 2;
                    startIndex = i;
                }
            }
            dp[i][i] = 1;
        }
        dp[size-1][size -1] = 1;

        for(int len = 3; len <= size; len++){
            for(i = 0; i <= size - len; i++){
                j = i + len - 1;
                if(str.charAt(i) == str.charAt(j) && dp[i+1][j-1] > 0){
                    dp[i][j] = len;
                    if(maxlength < len){
                        maxlength = len;
                        startIndex = i;
                    }
                }
            }
        }
        reString = str.substring(startIndex, startIndex + maxlength);
        return reString;
    }

    boolean checkIfPalidrome(String str, int i, int j){
        while(i < j){
            if(str.charAt(i) != str.charAt(j)){
                return false;
            }
            else {
                i++;
                j--;
            }
        }
        return true;
    }

    public static void main(String [] args){
        System.out.println("longest palidrome substring " + findLongstPalindromSubString("dfjhgdwdcf3221244rfe"));
        System.out.println("longest palidrome substring " + findLongstPalindromSubString("qwerttrewq"));
        System.out.println("longest palidrome substring " + findLongstPalindromSubString("qwerttrewqq2waaaaaa2112aaaa"));
    }
}