import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class LRUImplementation<K, V> {
    private Map<K, V> map = new HashMap<>();
    private LinkedList<K> list = new LinkedList<>();
    private int capacity = 5;
    private int ListSize = 0;

    public void putInCache(K key, V Value){
        if(capacity > ListSize){
            map.put(key, Value);
            list.add(key);
            ListSize++;
        } else if(capacity == list.size()){
            K prevKey = list.removeFirst();
            map.put(key, Value);
            list.add(key);
            map.remove(prevKey);
        }
    }

    public V getValueFromCache(K key){
        V value = null;
        if(map.containsKey(key)){
            value = map.get(key);
            list.remove(key);
            list.addLast(key);
        }
        return value;
    }

    public void printList(){
        System.out.println(list);
        System.out.println(map);
    }

    public static void main(String[] args) {
        LRUImplementation<Character, Integer> lru = new LRUImplementation<Character, Integer>();
        lru.putInCache('a', 1);
        lru.putInCache('b', 2);
        lru.putInCache('c', 3);
        lru.putInCache('d', 4);
        lru.getValueFromCache('b');
        lru.putInCache('e', 5);
        lru.putInCache('f', 6);
        lru.getValueFromCache('d');
        lru.putInCache('g', 7);
        lru.putInCache('f', 10);
        lru.getValueFromCache('d');
        // System.out.println(lru.map.size());
        lru.getValueFromCache('e');
        System.out.println(lru.getValueFromCache('a'));

        lru.printList();
    }
}

