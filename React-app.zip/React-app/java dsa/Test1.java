import java.util.HashSet;
import java.util.Set;

public class Test1 {
    // input arr = [1,2,3,4,5] , k =2 , output - [4,5,1,2,3]
    public static void main(String [] args){
        int [] arr = {1,2,3,4,5};
        int n = arr.length;
        int [] res = new int[n];
        int k = 5;
        if(k >= n){
            k = k % n;
        }
        for(int i = 0; i < n; i++){
            res[(i + k)%n] = arr[i];
        }     
        // for(int i = 0; i < n; i++){     
        //     System.out.print(res[i] + " ");
        // }

        String str1 = "Nehaassa";
        String str2 = "Pieyowojdasw";

        char [] str1Arr = str1.toCharArray();
        Set<Character> set = new HashSet<>();
        Set<Character> set2 = new HashSet<>();


        for(char ch : str1Arr){
            set.add(ch);
        }

        for(int i = 0; i < str2.length(); i++){
            char ch = str2.charAt(i);
            if(set.contains(ch)){
                set.remove(ch);
            } else {
                set2.add(ch);
            }
        }
        set.addAll(set2);

        System.out.println(set);
    }
   // Input: N = 5, array[] = {1,2,3,4,5} Output: 120 60 40 30
}
