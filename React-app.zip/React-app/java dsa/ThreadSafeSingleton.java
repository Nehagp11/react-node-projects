public class ThreadSafeSingleton {
    // Creating private instance to make it accessible only by getInstance() method
 private static ThreadSafeSingleton instance;
 private ThreadSafeSingleton(){
   // Making constructor private so that objects cant be initialized outside the class
   System.out.println("ThreadSafeSingleton Created");
 }

 public static ThreadSafeSingleton getInstance(){
   if (instance == null){
     //synchronized block of code
     synchronized (ThreadSafeSingleton.class){
       if(instance==null)
       {
         // initialize only if instance is null
         instance = new ThreadSafeSingleton();
       }
      
     }
   }
   return instance;
 }

 public static void main(String [] args){
    ThreadSafeSingleton.getInstance();
    Integer num1 = 1000, num2 = 1000;  
    System.out.println(num1 == num2);//1
    Integer num3 = 20, num4 = 20;  
    System.out.println(num3 == num4);//2

    Y y = new Y();
    System.out.println(y.i);    //L5
 }
}

class X {
   static int i = 1111;

   static{
       i = i-- - --i;    //L1
       System.out.println(i);
   }

   {
       i = i++ + ++i;    //L2
       System.out.println(i);
   }
}

class Y extends X{
   static{
       i = --i - i--;    //L3
       System.out.println(i);
   }
   {
       i = ++i + i++;    //L4
       System.out.println(i);
   }
}
