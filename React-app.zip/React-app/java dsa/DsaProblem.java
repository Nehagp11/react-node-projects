import java.util.List;
import java.util.Stack;

public class DsaProblem {
    public static boolean areBracketsBalanced(String s)
    {
        int i = -1;
        char[] stack = new char[s.length()];
        for (char ch : s.toCharArray()) {
            if (ch == '(' || ch == '{' || ch == '[')
                stack[++i] = ch;
            else {
                if (i >= 0
                    && ((stack[i] == '(' && ch == ')')
                        || (stack[i] == '{' && ch == '}')
                        || (stack[i] == '[' && ch == ']')))
                    i--;
                else
                    return false;
            }
        }
        return i == -1;
    }

    static int lcs(String X, String Y, int m, int n, int[][] dp)
    {
 
        if (m == 0 || n == 0)
            return 0;
 
        if (dp[m][n] != -1)
            return dp[m][n];
 
        if (X.charAt(m - 1) == Y.charAt(n - 1)) {
            dp[m][n] = 1 + lcs(X, Y, m - 1, n - 1, dp);
            return dp[m][n];
        }
 
        dp[m][n] = Math.max(lcs(X, Y, m, n - 1, dp), lcs(X, Y, m - 1, n, dp));
        return dp[m][n];
    }

    static void printStack()
    {
        Stack<Integer> St = new Stack<Integer>();
        int arr[] = {1, 2, 3, 5}; 
        int N = arr.length;

        for(int i = 0; i < N; i++){
            St.push(arr[i]);
        }
    
        // Traverse the stack
        while (!St.isEmpty()) {
    
            // Print top element
            System.out.print(St.peek() +" size : " + St.size()+ " ");
    
            // Pop top element
            St.pop();
        }
    }
 
    public static void main(String[] args)
    {
        String expr = "{())[]";
 
        // Function call
        if (areBracketsBalanced(expr))
            System.out.println("Balanced");
        else
            System.out.println("Not Balanced");

        String X = "ATAB";
        String Y = "AGXTXAYB";

        int m = X.length();
        int n = Y.length();
        int[][] dp = new int[m + 1][n + 1];
        for (int i = 0; i < m + 1; i++) {
            for (int j = 0; j < n + 1; j++) {
                dp[i][j] = -1;
            }
        }
        System.out.println("Length of LCS is " + lcs(X, Y, m, n, dp));    

        printStack();
    }
}