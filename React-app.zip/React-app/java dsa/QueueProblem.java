import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;

public class QueueProblem {
    public static void main(String args[])
    {
        // Creating empty priority queue
        Queue<Integer> pQueue = new PriorityQueue<Integer>();
 
        // Adding items to the pQueue
        // using add()
        pQueue.add(20);
        pQueue.add(15);
        pQueue.add(5);
        pQueue.add(18);
        pQueue.add(35);
        pQueue.add(10);
        // Printing the top element of
        // the PriorityQueue
        System.out.println("Queue is :" + pQueue);

        System.out.println(pQueue.peek());
 
        // Printing the top element and removing it
        // from the PriorityQueue container
        System.out.println(pQueue.poll());
 
        // Printing the top element again
        System.out.println(pQueue.peek());

        System.out.println(pQueue.remove());
        System.out.println(pQueue.size());

        System.out.println(pQueue.poll());

        System.out.println("Queue is :" + pQueue);

        Iterator iterator = pQueue.iterator();
 
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }

        // define capacity of PriorityBlockingQueue
        int capacity = 15;
  
        // create object of PriorityBlockingQueue
        PriorityBlockingQueue<Integer> pbq
            = new PriorityBlockingQueue<Integer>(
                capacity, Comparator.reverseOrder());
  
        // add  numbers
        pbq.add(1);
        pbq.add(2);
        pbq.add(3);
  
        // print queue
        System.out.println("PriorityBlockingQueue:" + pbq);

        System.out.println(pbq.poll());
        System.out.println(pbq.peek());

        System.out.println("Queue is :" + pbq);

        LinkedList<String> ll = new LinkedList<String>();
  
        // Adding elements to the linked list
        ll.add("A");
        ll.add("B");
        ll.addLast("C");
        ll.addFirst("D");
        ll.add(2, "E");
  
        System.out.println(ll);
        
        ll.removeFirst();
        ll.removeLast();
  
        System.out.println(ll);

        ll.remove(1);

        System.out.println(ll);

        ll.remove("B");

        System.out.println(ll);

        ll.add("C");
        ll.add("E");

        for(String i : ll){
            System.out.print(i + " ");
        }
    }
}
