import java.util.Stack;
import java.util.logging.Level;

class Node {
    int data;
    Node left, right;
    public Node(int data)
    {
        this.data = data;
        left = right = null;
    }
}

public class BinaryTree {
    Node root;
    // head --> Pointer to head node of created doubly
    // linked list
    Node head;
  
    // Initialize previously visited node as NULL. This is
    // static so that the same value is accessible in all
    // recursive calls
    static Node prev = null;
  
    // A simple utility recursive function to convert a
    // given Binary tree to Doubly Linked List root --> Root
    // of Binary Tree
    void BTree2DoublyLinkedList(Node root)
    {
        // Base case
        if (root == null)
            return;
  
        // Recursively convert left subtree
        BTree2DoublyLinkedList(root.left);
  
        // Now convert this node
        if (prev == null)
            head = root;
        else {
            root.left = prev;
            prev.right = root;
        }
        prev = root;
  
        // Finally convert right subtree
        BTree2DoublyLinkedList(root.right);
    }

    static Node CurrentNode;

    Node doublyLinkedListToBtree(int N){
        if(CurrentNode == null || N <= 0){
            return null; 
        }
        Node leftTree = doublyLinkedListToBtree(N/2);
        Node root = CurrentNode;
        CurrentNode = CurrentNode.right;
        root.left = leftTree;
        root.right = doublyLinkedListToBtree(N - N/2 - 1);
        return root;
    }

    void DLLToBtree(Node head){
        int N = countNodes(head);
        CurrentNode = head;
        root = doublyLinkedListToBtree(N);
        CurrentNode = root;
        // CurrentNode = root;
        levelOrderTraversal(root);
        preOrdertraversal(CurrentNode);
    }

    void preOrdertraversal(Node root){
        if(root == null){
            return;
        }
        System.out.print(root.data + " ");
        if(root.left != null){
            preOrdertraversal(root.left);
        }
        if(root.right != null){
            preOrdertraversal(root.right);
        }
    }

    void levelOrderTraversal(Node root){
        if(root == null){
            return;
        }

        int level = 0;
        Stack<Node> evenLevels = new Stack<Node>();
        Stack<Node> oddLevels = new Stack<Node>();
        
        evenLevels.push(root);

        while(!evenLevels.isEmpty() || !oddLevels.isEmpty()){
            while (!evenLevels.isEmpty() && level % 2 == 0) {
                Node currentNode = evenLevels.pop();
                System.out.println(currentNode.data + " level - " + level);
                if(currentNode.right != null){
                    oddLevels.push(currentNode.right);
                }
                if(currentNode.left != null){
                    oddLevels.push(currentNode.left);
                } 
            }
            level++;
            while (!oddLevels.isEmpty() && level % 2 == 1) {
                Node currentNode = oddLevels.pop();
                System.out.println(currentNode.data + " level - " + level);
                if(currentNode.left != null){
                    evenLevels.push(currentNode.left);
                }
                if(currentNode.right != null){
                    evenLevels.push(currentNode.right);
                } 
            }
            level++;
        }
    }

    int countNodes(Node head){
        Node current = head;
        int count = 0;
        while(current != null){
            current = current.right;
            count++;
        }
        return count;
    }

    void BTree2CircularDoublyLinkedList(Node root)
    {
        BTree2DoublyLinkedList(root);
        // make the changes to convert a DLL to CDLL
        prev.right = head;
        head.left = prev;
    }

    void printList(Node node)
    {
        if (node == null)
            return;
        Node curr = node;
        do {
            System.out.print(curr.data + " ");
            curr = curr.right;
        } while (curr != null);
    }
  
    // Driver program to test above functions
    public static void main(String[] args)
    {
        // Let us create the tree as shown in above diagram
        BinaryTree tree = new BinaryTree();
        tree.root = new Node(10);
        tree.root.left = new Node(12);
        tree.root.right = new Node(15);
        tree.root.left.left = new Node(25);
        tree.root.left.right = new Node(30);
        tree.root.right.right = new Node(54);
        tree.root.right.left = new Node(76);
        tree.root.right.left.right = new Node(326);
        tree.root.right.right.left = new Node(26);

        // convert to DLL
        tree.BTree2DoublyLinkedList(tree.root);
  
        // Print the converted List
        // 
        tree.CurrentNode = tree.head;
        tree.printList(tree.CurrentNode);

        tree.DLLToBtree(tree.head);
    }
}


