import java.util.Arrays;

public class StringProblem {
    static void reverse(char[] str, int start, int end)
    {
        // Temporary variable
        // to store character
        char temp;
 
        while (start <= end) {
            // Swapping the first
            // and last character
            temp = str[start];
            str[start] = str[end];
            str[end] = temp;
            start++;
            end--;
        }
    }
    // Function to reverse words
    static char[] reverseWords(char[] s)
    {
        // Reversing individual words as
        // explained in the first step
 
        int start = 0;
        for (int end = 0; end < s.length; end++) {
            // If we see a space, we
            // reverse the previous
            // word (word between
            // the indexes start and end-1
            // i.e., s[start..end-1]
            while(s[start] == ' '){
                start++;
                end++;
            }

            if (s[end] == ' ') {
                reverse(s, start, end);
                start = end + 1;
            }
        }
 
        // Reverse the last word
        reverse(s, 0, s.length - 1);
 
        // Reverse the entire String
        start = 0;
         while(s[start] == ' '){
            start++;
            // end++;
        }
        reverse(s, start, s.length - 1);
        return s;
    }

    public static String removeSpaces(String s) {
        int n = s.length();
        int i = 0, j = -1;
        boolean spaceFound = false;
         
        // Handles leading spaces
        while (j < n - 1 && s.charAt(j + 1) == ' ') {
            j++;
        }
         
        // read all characters of original string
        while (j < n) {
            // if current characters is non-space
            if (s.charAt(j) != ' ') {
                // remove preceding spaces before dot,
                // comma & question mark
                if ((s.charAt(j) == '.' || s.charAt(j) == ',' || s.charAt(j) == '?') && i - 1 >= 0 && s.charAt(i - 1) == ' ') {
                    s = s.substring(0, i - 1) + s.charAt(j) + s.substring(i);
                    j++;
                } else {
                    // copy current character at index i
                    // and increment both i and j
                    s = s.substring(0, i) + s.charAt(j) + s.substring(i + 1);
                    i++;
                    j++;
                }
                spaceFound = false;
        } else if (s.charAt(j) == ' ') {
            // If space is encountered for the first
            // time after a word, put one space in the
            // output and set space flag to true
            if (!spaceFound) {
                s = s.substring(0, i) + ' ' + s.substring(i + 1);
                i++;
                spaceFound = true;
            }
            j++;
        }
    }
     
    // Remove trailing spaces
    if (i <= 1) {
        s = s.substring(0, i);
    } else {
        s = s.substring(0, i - 1);
    }
    return s;
}

    static int shortestDistance(String[] s, String word1, String word2)
    {
        int d1 = -1, d2 = -1;
        int ans = Integer.MAX_VALUE;
    
        // Traverse the string
        for (int i = 0; i < s.length; i++) {
            if (s[i] == word1)
                d1 = i;
            if (s[i] == word2)
                d2 = i;
            if (d1 != -1 && d2 != -1)
                ans = Math.min(ans, Math.abs(d1 - d2));
        }
        return ans;
    }

    static int size = 256;
 
    // Function returns true if str1 and str2 are isomorphic
    static String areIsomorphic(String str1, String str2)
    {
        int m = str1.length();
        int n = str2.length();
 
        // Length of both strings must be same for one to
        // one correspondence
        if (m != n)
            return "False";
 
        // To mark visited characters in str2
        Boolean[] marked = new Boolean[size];
        Arrays.fill(marked, Boolean.FALSE);
 
        // To store mapping of every character from str1 to
        // that of str2. Initialize all entries of map as
        // -1.
        int[] map = new int[size];
        Arrays.fill(map, -1);
 
        // Process all characters one by one
        for (int i = 0; i < n; i++) {
            // If current character of str1 is seen first
            // time in it.
            if (map[str1.charAt(i)] == -1) {
                // If current character of str2 is already
                // seen, one to one mapping not possible
                if (marked[str2.charAt(i)] == true)
                    return "False";
 
                // Mark current character of str2 as visited
                marked[str2.charAt(i)] = true;
 
                // Store mapping of current characters
                map[str1.charAt(i)] = str2.charAt(i);
            }
 
            // If this is not first appearance of current
            // character in str1, then check if previous
            // appearance mapped to same character of str2
            else if (map[str1.charAt(i)] != str2.charAt(i))
                return "False";
        }
        System.out.println("Map is : " + map.toString());
        return "True";
    }

    static String longestCommonPrefix(String[] a)
    {
        int size = a.length;
 
        /* if size is 0, return empty string */
        if (size == 0)
            return "";
 
        if (size == 1)
            return a[0];
 
        /* sort the array of strings */
        // Arrays.sort(a);
 
        /* find the minimum length from first and last string */
        // int end = Math.min(a[0].length(), a[size-1].length());
        int j = 0;
         /* find the common prefix between the first and
           last string */
        int i = 0;
        String pre = "";
        int end = Math.min(a[0].length(), a[1].length());
        while(j < end && a[0].charAt(j) == a[1].charAt(j)){
            j++;
        }
        pre = a[0].substring(0, j);
        end = j;
        for(i = 2; i < size; i++){
            j = 0;
            end = Math.min(a[i].length(), pre.length());
            while(j < end && a[i].charAt(j) == pre.charAt(j)){
                j++;
            }
            if(j < pre.length()){
                pre = a[0].substring(0, j);
                // end = j;
            }
        }

        // while (i < end && a[0].charAt(i) == a[size-1].charAt(i))
        //      i++;
        return pre;
    }

    static class InterviewBitThreadExample implements Runnable {  
        public void run(){  
            System.out.println("Thread runs...");  
        }  
    }

    public static int testExceptionDivide(int a, int b) throws ArithmeticException {
        if(a == 0 || b == 0)
            throw new ArithmeticException();
        return a/b;
    }

    // Driver Code
    public static void main(String[] args)
    {
        String s = "   i   like this   program very much ";
 
        // Function call
        char[] p = reverseWords(s.toCharArray());
        System.out.println(p);

        String str = "   Hello Geeks . Welcome   to"
            + "  GeeksforGeeks   .    ";
        str = removeSpaces(str);
        System.out.println(str);
         
        System.out.println("Strings are isomorphic : " + areIsomorphic("qwrb", "acde"));  
        
        String[] input = {"geeksforgeeks", "geeks", "geek", "geezer"};
        System.out.println( "The longest Common Prefix is : " + longestCommonPrefix(input));

        // StringBuilder is suitable for an environment with a single thread, and a StringBuffer is suitable for multiple threads.
        String first = "InterviewBit";
        String second = new String("InterviewBit");
        // StringBuffer
        StringBuffer third = new StringBuffer("InterviewBit");
        // StringBuilder
        StringBuilder fourth = new StringBuilder("InterviewBit");

        System.out.println("first two comparison "+ second.equals(first));
        System.out.println("last two comparison "+ third.equals(second));

        Thread ib = new Thread(new InterviewBitThreadExample());
        ib.start(); 

        // https://www.interviewbit.com/java-interview-questions/

        // start() method is used for creating a separate call stack for the thread execution. Once the call stack is created, JVM calls the run() method for executing the thread in that call stack.

        try{
            testExceptionDivide(10, 0);
        }
        catch(ArithmeticException e){
            //Handle the exception
            System.out.println("An Airtmetic exception found "+ e);
        }

    }

}
