public class FooImplementation implements Foo {
    
}
