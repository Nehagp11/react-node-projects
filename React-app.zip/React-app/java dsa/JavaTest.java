import java.util.HashMap;
import java.util.Scanner;

public class JavaTest {
    public static void main(String args[]) {
        Scaler s = new Scaler(5);
        System.out.println('b');

        Scaler s1 = new Scaler();

        // Scanner scn = new Scanner(System.in);
        int z = 908; //input the number
		System.out.println("The sum of digits in " + z + " are: " + countDigits(z));

        Scanner scn = new Scanner(System.in);
        double n = scn.nextDouble(); //input the number
		int d = scn.nextInt(); //input the digit

        int x = countDigitFreq(n,d);
		System.out.println("The digit " + d + " occurs " + x + " times in " + n);

        // program to toggle every character of a String upperCase to LowerCase and LowerCase to Uppercase

        String str = scn.nextLine();
        StringBuilder res = new StringBuilder("");

        for(int i=0;i<str.length();i++) {
            char ch = str.charAt(i); //current character
            if(ch >='A' && ch <= 'Z') {
                res.append((char)(ch + 32));
            } else if(ch >='a' && ch<='z'){
                res.append((char)(ch - 32));
            } else { 
                res.append(ch);
            }
        }
        String ans = res.toString();
        System.out.println("The string after toggling becomes: " + ans);

    }

    public static int countDigits(int n) {
		if(n == 0) return 0;

		//if a negative number is entered
		if(n < 0) n = -n;

        int res = 0;
		while(n != 0) {
			res += n%10;
            n = n/10;
		}
		return res;
	}

    public static int countDigitFreq(double n,int D) {
		if(n == 0 && D == 0) return 1; //number 0 has 1 frequency of 0

		//if a negative number is entered
		if(n < 0) n = -n;

		int counter = 0;
		while(n != 0) {
			int digit = (int)n % 10; //calculate the digit
			if(digit == D) counter++; 
			n = n/10;
		}
		return counter;
	}

    public static boolean isAnagram(String s1, String s2) {     
        if(s1.length() != s2.length()) return false;
        
        HashMap<Character,Integer> fmap = new HashMap<>();
        
        for(int i=0;i<s1.length();i++) {
            int ofreq = fmap.getOrDefault(s1.charAt(i),0);
            fmap.put(s1.charAt(i),ofreq+1);
        }
        
        for(int i=0;i<s2.length();i++) {
            if(!fmap.containsKey(s2.charAt(i)) || fmap.get(s2.charAt(i)) == 0) {
                return false;
            } else {
                int ofreq = fmap.get(s2.charAt(i));
                fmap.put(s2.charAt(i),ofreq-1);
            }
        }
        return true;
    }
}
class InterviewBit{
    InterviewBit(){
        System.out.println(" Welcome to InterviewBit ");
    }
}
class Scaler extends InterviewBit{
    Scaler(){
        System.out.println(" Welcome to Scaler Academy ");
    }
    Scaler(int x){
        // this();
        super();
        System.out.println(" Welcome to Scaler Academy 2");
    }
}

// An example of Lambda expression where we can call function interface method directly with anonymous function

// FunctionalInterface fi = (String name) -> { 
// System.out.println("Hello "+name); 
// return "Hello "+name; 
// }


    // Collections.sort(mfSchemeMiniList, new Comparator<InternalMRRMFSchemeMiniDTO>() {
    //     public int compare(InternalMRRMFSchemeMiniDTO o1, InternalMRRMFSchemeMiniDTO o2) {
    //         return o1.etmRank() > o2.etmRank() ? 1 : o1.etmRank() < o2.etmRank() ? -1 : doSecodaryOrderSort(o1, o2);
    //     }

    //     public int doSecodaryOrderSort(InternalMRRMFSchemeMiniDTO o1, InternalMRRMFSchemeMiniDTO o2) {
    //         return o1.nameOfScheme().compareTo(o2.nameOfScheme());
    //     }
    // });

// https://www.interviewbit.com/java-8-interview-questions/
// https://www.interviewbit.com/java-programming-interview-questions/#java-code-to-check-given-strings-are-anagrams-or-not
// finally block will be executed irrespective of the exception or not. The only case where finally block is not executed is when it encounters ‘System.exit()’ method anywhere in try/catch block.

