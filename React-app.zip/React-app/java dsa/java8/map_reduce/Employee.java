import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class Employee {
    private int id;
    private String name;
    private String grade;
    private double salary;

    public Employee() {
    }

    public Employee(int id, String name, String grade, double salary) {
        this.id = id;
        this.name = name;
        this.grade = grade;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    static class EmployeeDatabase {
    public static List<Employee> getEmployees(){
      return  Stream.of(new Employee(101,"john","A",60000),
              new Employee(109,"peter","B",30000),
              new Employee(102,"mak","A",80000),
              new Employee(103,"kim","A",90000),
              new Employee(104,"json","C",15000)).collect(Collectors.toList());
    }
}

// @Override
// public String toString(Employee e1){
//     return "Employee : " + e1.getName() + ", " + e1.getGrade() + " ," + e1.getSalary();
// }

public String toString() {
    return this.getClass().getName() + "@" + this.getName() + ", " + this.getGrade() + " ," + this.getSalary();
 }

public static void main(String[] args) {
             //get employee whose grade A
        //get salary
        double avgSalary = EmployeeDatabase.getEmployees().stream()
                .filter(employee -> employee.getGrade().equalsIgnoreCase("A"))
                .map(employee -> employee.getSalary())
                .mapToDouble(i -> i)
                .average().getAsDouble();

        System.out.println(avgSalary);
        
        DoubleStream map1Stream = EmployeeDatabase.getEmployees().stream().filter(employee -> employee.getGrade().equalsIgnoreCase("A")).map(employee -> employee.getSalary()).mapToDouble(i -> i);

        // System.out.println(map1Stream);

        double sumSalary = EmployeeDatabase.getEmployees().stream()
                .filter(employee -> employee.getGrade().equalsIgnoreCase("A"))
                .map(employee -> employee.getSalary())
                .mapToDouble(i -> i)
                .sum();
        System.out.println(sumSalary);   

        // get max salary employee in each Grade 

        Map<String, List<Employee>> collect = EmployeeDatabase.getEmployees().stream().collect(Collectors.groupingBy(Employee::getGrade));

        Map<String, Optional<Employee>> collect1 = EmployeeDatabase.getEmployees().stream().collect(Collectors.groupingBy(Employee::getGrade, Collectors.reducing(BinaryOperator.maxBy(Comparator.comparing(Employee::getSalary)))));
        System.out.println(collect1);
    }
}
