class Table {

    // run without marking synchronized keyword in function
public void display(int n) {
	 for (int i = 1; i <= 100; i++) {
	  System.out.println(n * i);
	 }
 }
}

class Thread1 extends Thread {
	Table t;	
	 
	public Thread1(Table t) {
	 	this.t = t;
	}
	public void run() {
	 	t.display(5);
        try {
	   	 Thread.sleep(100);
	   } catch (InterruptedException e) {
	   	 System.out.println(e);
	   }
	}
}

class Thread2 extends Thread {
	Table t;
	public Thread2(Table t) {
	this.t = t;
	}
	public void run() {
	t.display(6);
	}
}

public class ThreadTest {
     public static void main(String[] args) {
 	 Table table = new Table();
 	 Thread1 th1 = new Thread1(table);
 	 Thread2 th2 = new Thread2(table);
 	 th1.start();
     // th1.sleep(100);
 	 th2.start();
    }
}

