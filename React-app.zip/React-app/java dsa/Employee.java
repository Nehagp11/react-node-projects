import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Employee{
    int id;
    String name;
    String city;

    public Employee(int id, String name, String city){
        this.id = id;
        this.name = name;
        this.city = city;
    }

    public static void filterCityWise(ArrayList<Employee> list, String cityName){
        Comparator<Employee> comparefn = (e1, e2) -> e2.name.compareTo(e1.name);
        // List<Employee> filteredList = list.stream().filter(e->e.city.equals(cityName)).sorted(comparefn).collect(Collectors.toList());
        list.stream().filter(e->e.city.equals(cityName)).sorted((e1, e2) -> e2.name.compareTo(e1.name)).forEach(e->System.out.println(e.name));
        // for(int i = 0; i < size; i++){
        //     Employee curEmployee = list.get(i);
        //     if(curEmployee.city.equals(cityName)){
        //         filteredList.add(curEmployee);
        //     }
        // }


        // if(!filteredList.isEmpty()){
        //     // Collections.sort(filteredList, new Comparator<Employee> () {
        //     //     public int compare(Employee e1, Employee e2){
        //     //         int gap = e2.name.compareTo(e1.name);
        //     //         return gap;
        //     //     }
        //     // });

        //     Collections.sort(filteredList, comparefn);
        // // }
        // for(int i = 0; i < filteredList.size(); i++){
        //     Employee curEmployee = filteredList.get(i);
        //     System.out.println(curEmployee.name);
        // }
        // return filteredList;
    }

    public static void main(String [] args){
        ArrayList<Employee> list = new ArrayList<Employee>();
        list.add(new Employee(12, "Neha", "Pune"));
        list.add(new Employee(14, "Pegha", "Pune"));
        list.add(new Employee(16, "Pooja", "Mumbai"));
        list.add(new Employee(17, "Chiranhivi", "Pune"));
        list.add(new Employee(18, "Annie", "Pune"));

        Employee.filterCityWise(list, "Pune");

        Function<Integer, String> func1 = (t)-> "output is .."+ t;
        System.out.println(func1.apply(123));
 
        List<Integer> list1 = Arrays.asList(12,34,9,3, 5, 45);
        // convert list into stream filter elements greater than 8 and sort and print 

        list1.stream().filter(t->t>8).sorted().forEach(System.out::println);

        // find frequency of each charcter in a string using stream and grouping by methods

        String input = "scfr5t43 23rrfegf";

        System.out.println(Arrays.stream(input.split("")).collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));

        // parallel stram to print numbers for a range with executing thread name 

        IntStream.rangeClosed(1, 12).parallel().forEach(t -> System.out.println(Thread.currentThread().getName() + " : " + t));
    }
}
