import './App.css';
import React from "react";
import App from './ReactTest'

function AppClock() {
  return (
    <div className="main-container">
      <h1> React Platform </h1>
      <App />
    </div>
  );
}

export default AppClock;
